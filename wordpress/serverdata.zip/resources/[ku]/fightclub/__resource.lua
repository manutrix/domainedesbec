resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

this_is_a_map 'yes'

client_script {
    "config.lua",

    "libs/debugger.lua",

    "client/client.lua",
    "client/client_events.lua",

    "client/zones/zones_manager.lua",
    "client/zones/zones_callbacks.lua",
    "client/zones/zones.lua"
}

server_script {
    -- https://brouznouf.github.io/fivem-mysql-async/queries/
    '@mysql-async/lib/MySQL.lua',

    "config.lua",

    "libs/debugger.lua",
    "libs/chunk_manager.lua",

    "server/server.lua",
    "server/server_events.lua"
}

ui_page {
    'ui/fightclub.html'
}

files({
    'ui/fightclub.html',

    'ui/js/fightclub.js',
    'ui/js/vendor/jquery.3.5.0.min.js',

    'ui/css/fightclub.css',
    
	'ui/fonts/pricedown.black.ttf',
    
    'ui/images/overlay/center.png',
    'ui/images/overlay/energybar.png',
    'ui/images/overlay/overlay_red.png',
    'ui/images/overlay/overlay_blue.png',
    'ui/images/fightclub.png',
    'ui/images/fightclub_50.png',
    'ui/images/fightclub_bullet.png'
})