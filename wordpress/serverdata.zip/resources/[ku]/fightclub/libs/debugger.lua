if Configs.enable_debug_messages then
    print("Fightclub debug enabled")
end

local debug_calling_function = nil
function print_debug(msg, detail)
    if Configs.enable_debug_messages then
        if debug.getinfo(2).name ~= debug_calling_function then
            print("\n**** " .. debug.getinfo(2).name .. " ****")
            debug_calling_function = debug.getinfo(2).name
        end

        if type(msg) == 'table' then    
            if detail then
                print(ESX.DumpTable(msg))
            else
                for ind, val in pairs(msg) do
                    print(ind)
                    print(val)
                    print("")
                end
            end
        else
            print(msg)
        end
    end
end

function print_table_keys(tbl)
    for k, v in pairs(tbl) do
        print(k)
     end
end

function get_table_length(tbl)
    local count = 0
    for _ in pairs(tbl) do count = count + 1 end
    return count
end

function dump(o)
    local s = ""

    if type(o) == 'table' then
        s = '{'
        for k, v in pairs(o) do
            s = s .. '"' .. k .. '":'

            if v == nil then
                s = s .. ""
            elseif type(v) == 'table' then
                s = s .. dump(v)
            elseif type(v) == 'string' then
                s = s .. '"' .. v .. '"'
            elseif type(v) == 'boolean' then
                s = s .. tostring(v)
            elseif type(v) == 'number' then
                s = s .. v
            else
                s = s .. type(v)
            end

            s = s .. ","
        end

        if string.sub(s,string.len(s)) == "," then
            s = string.sub(s,0,string.len(s)-1)
        end

        s =  s .. '}'
    end

    return s
end