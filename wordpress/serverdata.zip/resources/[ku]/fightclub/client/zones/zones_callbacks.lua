-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<  SCENARIO CALLBACKS >>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function can_access_zone_scenario_area()
    return true
end

function get_in_scenario_area()
    scenario_assets(true)
end

function get_out_scenario_area()
    scenario_assets(false)
end

function in_scenario_area()
    if is_fighter('blue') then
        zones.ring_corner.color = { r=0, g=0, b=204 }
        zones.ring_corner.coords = { x = -517.94, y =  -1708.0, z = 20.46, h = 185.78 }
        zones.ring_entry.coords = { x = -513.19, y =  -1708.78, z = 19.3, h = 333.3 }
    elseif is_fighter('red') then
        zones.ring_corner.color = { r=204, g=0, b=0 }
        zones.ring_corner.coords = { x = -517.46, y =  -1716.0, z = 20.46, h = 6.0 }
        zones.ring_entry.coords = { x = -520.6, y =  -1716.92, z = 19.32, h = 138.38 }
    end
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<  REGISTER CALLBACKS >>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function can_access_zone_register()
    return tournament.registration.is_started and (not player.registered)
end

function get_in_register()
    register_form(true)
    SetNuiFocus(true, true)
end

function get_out_register()
    register_form(false)
    SetNuiFocus(false)
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<  BOOKMAKER CALLBACKS >>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function can_access_zone_bookmaker()
    return tournament.bookmaker.is_started and (not player.has_bet)
end

function get_in_bookmaker()
    bookmaker_form(true)
    SetNuiFocus(true, true)
    -- bookmaker_bet()
end

function get_out_bookmaker()
    bookmaker_form(false)
    SetNuiFocus(false)
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<  RING ENTRY CALLBACKS >>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function can_access_zone_ring_entry()
    return tournament.bookmaker.is_started
end

function can_access_zone_ring_entry_red()
    return can_access_zone_ring_entry() and player.combat.color == "red"
end

function can_access_zone_ring_entry_blue()
    return can_access_zone_ring_entry() and player.combat.color == "blue"
end

function get_in_ring_entry()
    get_in_ring()
end

function get_out_ring_entry()
    --get_out_ring()
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<  RING CORNER CALLBACKS >>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function can_access_zone_ring_corner(color)
    if tournament.ongoing then
        return (
            player.combat.dressed and
            player.combat.color == color and
            (
                tournament.ongoing.round.rest or
                tournament.bookmaker.is_started
            )
        )
    end

    return false
end

function can_access_zone_ring_corner_red()
    return can_access_zone_ring_corner('red')
end

function can_access_zone_ring_corner_blue()
    return can_access_zone_ring_corner('blue')
end

function get_in_ring_corner()
    if tournament.ongoing.round.rest then
        start_rest_fighter()
    elseif tournament.bookmaker.is_started then
        immobilize_fighter()
    end
end

function get_out_ring_corner()
    stop_rest_fighter()
    unleash_fighter()
end

function in_ring_corner()

end