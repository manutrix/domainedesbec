zones = {}

Citizen.CreateThread(function()
    while player == nil do
        Citizen.Wait(0)
    end

    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(1)

            if tournament and tournament.is_started then
                player.coords = GetEntityCoords(PlayerPedId())
    
                for name, zone in pairs(zones) do
                    handle_zone(name, zone)
                end
            end
        end
    end)
end)

function handle_zone(name, zone)
    if zone.can_access_callback ~= nil and zone.can_access_callback() == true then
        if zone.color ~= nil then
            draw_zone_marker(zone)
        end

        if is_in_zone(zone) then
            if not zone.is_in_zone then
                if zone.get_in_callback ~= nil then
                    zone.get_in_callback()
                end
            end
            zone.is_in_zone = true

            if zone.in_callback ~= nil then
                zone.in_callback()
            end
        else
            if zone.is_in_zone then
                if zone.get_out_callback ~= nil then
                    zone.get_out_callback()
                end
            end
            zone.is_in_zone = false
        end
    end
end

function draw_zone_marker(zone)
    DrawMarker(1, zone.coords.x, zone.coords.y, zone.coords.z - 1, 0.0, 0.0, 0.0, 0, 0.0, 0.0, zone.size, zone.size, 0.3, zone.color.r, zone.color.g, zone.color.b, 100, false, true, 2, false, false, false, false)
end

function is_in_zone(zone)
    return GetDistanceBetweenCoords(player.coords, zone.coords.x, zone.coords.y, player.coords.z, true) < zone.size / 2
end