Citizen.CreateThread(function()
    while zones == nil do
        Citizen.Wait(0)
    end

    zones.scenario_area = {
        is_in_zone = false,
        coords = { x = -517.79, y = -1711.94, z = 20.46 },
        color = nil,
        size = 85.0,
        can_access_callback = function()
            return can_access_zone_scenario_area()
        end,
        get_in_callback = function()
            return get_in_scenario_area()
        end,
        get_out_callback = function()
            return get_out_scenario_area()
        end,
        in_callback = nil
    }

    zones.register = {
        is_in_zone = false,
        coords = { x = -522.71, y = -1715.19, z = 19.32 },
        color = { r=0, g=204, b=0 },
        size = 3.0,
        can_access_callback = function()
            return can_access_zone_register()
        end,
        get_in_callback = function()
            return get_in_register()
        end,
        get_out_callback = function()
            return get_out_register()
        end,
        in_callback = nil
    }

    zones.bookmaker = {
        is_in_zone = false,
        coords = { x = -522.81, y = -1725.54, z = 19.18 },
        color = { r=204, g=204, b=0 },
        size = 2.0,
        can_access_callback = function()
            return can_access_zone_bookmaker()
        end,
        get_in_callback = function()
            return get_in_bookmaker()
        end,
        get_out_callback = function()
            return get_out_bookmaker()
        end,
        in_callback = nil
    }

    zones.ring_corner_red = {
        is_in_zone = false,
        coords = { x = -517.46, y =  -1716.0, z = 20.46, h = 6.0 },
        color = { r = 204, g = 0, b = 0 },
        size = 1.5,
        can_access_callback = function()
            return can_access_zone_ring_corner_red()
        end,
        get_in_callback = function()
            return get_in_ring_corner()
        end,
        get_out_callback = function()
            return get_out_ring_corner()
        end,
        in_callback = function()
            return in_ring_corner()
        end
    }

    zones.ring_entry_red = {
        is_in_zone = false,
        coords = { x = -520.6, y =  -1716.92, z = 19.32, h = 138.38 },
        color = { r = 204, g = 0, b = 0 },
        size = 1.0,
        can_access_callback = function()
            return can_access_zone_ring_entry_red()
        end,
        get_in_callback = function()
            return get_in_ring_entry()
        end,
        get_out_callback = function()
            return get_out_ring_entry()
        end,
        in_callback = nil
    }

    zones.ring_corner_blue = {
        is_in_zone = false,
        coords = { x = -517.94, y =  -1708.0, z = 20.46, h = 185.78 },
        color = { r = 0, g = 0, b = 204 },
        size = 1.5,
        can_access_callback = function()
            return can_access_zone_ring_corner_blue()
        end,
        get_in_callback = function()
            return get_in_ring_corner()
        end,
        get_out_callback = function()
            return get_out_ring_corner()
        end,
        in_callback = function()
            return in_ring_corner()
        end
    }

    zones.ring_entry_blue = {
        is_in_zone = false,
        coords = { x = -513.19, y =  -1708.78, z = 19.3, h = 333.3 },
        color = { r = 0, g = 0, b = 204 },
        size = 1.0,
        can_access_callback = function()
            return can_access_zone_ring_entry_blue()
        end,
        get_in_callback = function()
            return get_in_ring_entry()
        end,
        get_out_callback = function()
            return get_out_ring_entry()
        end,
        in_callback = nil
    }

end)