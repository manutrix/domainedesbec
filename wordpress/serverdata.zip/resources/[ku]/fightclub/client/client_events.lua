-- <<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<< SERVER EVENTS >>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>
RegisterNetEvent("ku:scenario:fightclub:client:update_tournament")
AddEventHandler("ku:scenario:fightclub:client:update_tournament", function(tournament)
    update_tournament(tournament)
end)

RegisterNetEvent("ku:scenario:fightclub:client:dress_fighter")
AddEventHandler("ku:scenario:fightclub:client:dress_fighter", function(data)
    dress_fighter(data)
end)

RegisterNetEvent("ku:scenario:fightclub:client:undress_fighter")
AddEventHandler("ku:scenario:fightclub:client:undress_fighter", function(data)
    undress_fighter(data)
end)

RegisterNetEvent("ku:scenario:fightclub:client:tournament_fee")
AddEventHandler("ku:scenario:fightclub:client:tournament_fee", function(accepted)
    register_player(accepted)
end)

RegisterNetEvent("ku:scenario:fightclub:client:bookmaker_bet")
AddEventHandler("ku:scenario:fightclub:client:bookmaker_bet", function(accepted)
    bookmaker_bet(accepted)
end)

-- <<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<< UI EVENTS >>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>
RegisterNUICallback('accept_registeration', function()
    TriggerServerEvent('ku:scenario:fightclub:server:register_fighter')
end)

RegisterNUICallback('cancel_registeration', function(data)
    get_out_register()
end)

RegisterNUICallback('accept_bookmaker', function(data)
    TriggerServerEvent('ku:scenario:fightclub:server:place_bet', data.fighter, data.amount)
end)

RegisterNUICallback('cancel_bookmaker', function(data)
    get_out_bookmaker()
end)
