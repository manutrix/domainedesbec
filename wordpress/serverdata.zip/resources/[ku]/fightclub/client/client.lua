-- Bureau d'inscription
-- Bureau de paris
-- Bourse: split la bourse

ESX = nil
player = nil

tournament = {
    tournament_started = false
}

-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<  START EVENT HANDLER >>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>

-- TODO: Admin or Fightclub job
local Keys = { ["F5"] = 166, ["F7"] = 168 }
Citizen.CreateThread(function()
    local val = -1
    while true do
        Citizen.Wait(1)

        if IsControlJustReleased(0, Keys['F5']) and (not tournament.is_started) then
            TriggerServerEvent('ku:scenario:fightclub:server:start_scenario')
        end
    end
end)

-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<  INITIALIZATION >>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end

    player = {
        id = GetPlayerServerId(PlayerId()),
        entity = GetPlayerPed(-1),
        xdata = ESX.GetPlayerData(),
        coords = { x = 0.0, y = 0.0, z = 0.0 },

        lock_vision = false,
        lock_movement = false,

        registered = false,
        has_bet = false,

        combat = {
            color = nil,
            dressed = false,
            in_ring = false,
            is_resting = false
        }
    }

    ring_positions = {
        red = {
            entry = zones.ring_entry_red,
            corner = zones.ring_corner_red
        },
        blue = {
            entry = zones.ring_entry_blue,
            corner = zones.ring_corner_blue
        }
    }

    SetNuiFocus(false)
end)

-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<  MOVEMENT MANAGEMENT >>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)

        if tournament.is_started then
            if player.lock_movement then
                DisableControlAction(0, 24, true) -- INPUT_ATTACK
                DisableControlAction(0, 37, true) -- INPUT_SELECT_WEAPON

                DisableControlAction(0, 140, true) -- INPUT_MELEE_ATTACK_LIGHT
                DisableControlAction(0, 141, true) -- INPUT_MELEE_ATTACK_HEAVY
                DisableControlAction(0, 142, true) -- INPUT_MELEE_ATTACK_ALTERNATE

                DisableControlAction(0, 30, true) -- INPUT_MOVE_LR
                DisableControlAction(0, 31, true) -- INPUT_MOVE_UD
            end

            if player.lock_vision then
                DisableControlAction(0, 1,    true) -- LookLeftRight
                DisableControlAction(0, 2,    true) -- LookUpDown
            end
        end
    end
end)

function immobilize_fighter()
    player.lock_movement = true
end

function unleash_fighter()
    player.lock_movement = false
end

-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<  SCENARIO MANAGEMENT >>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
function register_player(accepted)
    call_ui('register_form_validation', {accepted = accepted})
    player.registered = accepted
end

function bookmaker_bet(accepted)
    call_ui('bookmaker_form_validation', {accepted = accepted})
    player.has_bet = accepted
end

-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<  COMBAT MANAGEMENT >>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>
function dress_fighter(data)
    player.combat.dressed = true
    player.combat.color = data
end

function undress_fighter(data)
    get_out_ring()

    player.combat.color = nil
    player.combat.dressed = false
end

function get_in_ring()
    if player.combat.dressed then
        local corner = ring_positions[player.combat.color].corner.coords

        SetEntityCoords(player.entity, corner.x, corner.y, corner.z, true, true, true)
        SetEntityHeading(player.entity, corner.h)

        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, fighterClothes)
            if skin.sex == 0 then
                TriggerEvent('skinchanger:loadClothes', skin, Configs.fighter.clothes.male[player.combat.color])
            else
                TriggerEvent('skinchanger:loadClothes', skin, Configs.fighter.clothes.female[player.combat.color])
            end
        end)

        SetPedMaxHealth(player.entity, Configs.fighter_health)
        SetEntityHealth(player.entity, Configs.fighter_health)

        player.combat.in_ring = true
    end
end

function get_out_ring()
    local exit = ring_positions[player.combat.color].entry.coords

    if player.combat.dressed then
        SetEntityCoords(player.entity, exit.x, exit.y, exit.z, true, true, true)
        SetEntityHeading(player.entity, exit.h)

        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, playerClothes)
            TriggerEvent('skinchanger:loadSkin', skin)
        end)
        
        -- TODO: Get the original health instead of hadcoding at 200
        SetPedMaxHealth(player.entity, 200)
        SetEntityHealth(player.entity, 200)

        player.combat.in_ring = false
    end
end

function start_rest_fighter()
    player.combat.is_resting = true
end

function stop_rest_fighter()
    player.combat.is_resting = false
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<  HEALTH MANAGEMENT >>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(250)

        if player.combat.dressed then
            if player.combat.is_resting then
                SetPedMaxHealth(player.entity, GetPedMaxHealth(player.entity) + Configs.fighter_health_restore)
            end

            TriggerServerEvent('ku:scenario:fightclub:server:fighter_report', {
                color = player.combat.color,
                health = GetEntityHealth(player.entity)
            })
        end
    end
end)

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<  UI MANAGEMENT >>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function call_ui(event, data)
    SendNUIMessage({
        action = event,
        data = data
    })
end

function update_tournament(t)
    tournament = t
    call_ui("update_tournament", tournament)

    if (not tournament.bookmaker.is_started) and player.combat.dressed then
        unleash_fighter()
    end

    if (not tournament.registration.is_started) and player.registered then
        player.registered = false
    end

    if (not tournament.bookmaker.is_started) and player.has_bet then
        player.has_bet = false
    end
end

function scenario_assets(show)
    call_ui('ui', {show = show})
end

function register_form(show)
    call_ui('register_form', {show = show})
end

function bookmaker_form(show)
    call_ui('bookmaker_form', {show = show})
end