# ku_scenario_fightclub

### Requirements
- [esx](https://github.com/ESX-Org/es_extended)

### Features
- 

## Installation
- Add this into your `server.cfg`

```
start ku_scenario_fightclub
```

docker run -d  --name tmp_apache -p 8081:80 -v E:\Patrick\Programmation\RP\tuc\server\resources\[scenario]\fightclub\ui:/usr/local/apache2/htdocs/ httpd:2.4