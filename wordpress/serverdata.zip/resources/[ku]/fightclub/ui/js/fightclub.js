$(function() {
    window.addEventListener('message', function(event) {
        var data = event.data.data;

        switch(event.data.action){
            case "update_tournament":
                tournament_started(data)
                registration_started(data)
                bookmark_started(data)
                fight_started(data)
                break;
            case "ui":
                ui(data.show);
                break;
            case "register_form":
                register_form(data.show);
                break;
            case "register_form_validation":
                register_form_validation(data.accepted);
                break;
            case "bookmaker_form":
                bookmaker_form(data.show);
                break;
            case "bookmaker_form_validation":
                bookmaker_form_validation(data.accepted);
                break;
        }
    })
});

//*******************************************/
//************ BOARD MANAGEMENT *************/
//*******************************************/
function tournament_started(tournament) {
    toggle_in_out($('div.overlays div.center'), tournament.is_started)
    toggle_in_out($('presented'), tournament.is_started)
}

function registration_started(tournament) {
    toggle_in_out($('div.overlays div.center div.info_registration'), tournament.registration.is_started)

    if (tournament.registration.is_started) {
        $('div.overlays div.center div.info_registration div.timer').html(msToTime(tournament.registration.time_remaining));
    }
}

function bookmark_started(tournament) {
    if (tournament.bookmaker.is_started) {
        if (!$('div.overlays div.center div.next').hasClass('in')) {
            $('div.overlays div.center div.next div.fighter.red').html(tournament.ongoing.fighters.red.name);
            $('div.bookmaker #red').html(tournament.ongoing.fighters.red.name);
            $('div.overlays div.center div.next div.fighter.blue').html(tournament.ongoing.fighters.blue.name);
            $('div.bookmaker #blue').html(tournament.ongoing.fighters.blue.name);
        }

        $('div.overlays div.center div.next div.timer').html(msToTime(tournament.bookmaker.time_remaining));
    }

    toggle_in_out($('div.overlays div.center div.next'), tournament.bookmaker.is_started)
}

function fight_started(tournament) {
    if(tournament.ongoing) {
        $('div.overlays div.fighter.red .name').html(tournament.ongoing.fighters.red.name);
        $('div.overlays div.fighter.blue .name').html(tournament.ongoing.fighters.blue.name);

        $('div.overlays div.fighter.red .energybar .energy').width(((tournament.ongoing.fighters.red.health/1000) * 100) + "%")
        $('div.overlays div.fighter.blue .energybar .energy').width(((tournament.ongoing.fighters.blue.health/1000) * 100) + "%")

        toggle_in_out($('div.overlays div.center div.combat'), tournament.ongoing.round.is_started);
        toggle_in_out($('div.overlays div.fighter.red'), tournament.ongoing.round.is_started);
        toggle_in_out($('div.overlays div.fighter.blue'), tournament.ongoing.round.is_started);

        if(tournament.ongoing.round.rest) {
            $('div.overlays div.center div.combat div.round').html("Pause");
        }
        else {
            $('div.overlays div.center div.combat div.round').html("Round " + tournament.ongoing.round.number);
        }

        $('div.overlays div.center div.combat div.timer').html(msToTime(tournament.ongoing.round.time));
    }
}

//*******************************************/
//************* UI MANAGEMENT ***************/
//*******************************************/
function ui(show) {
    toggle_in_out($('body'), show)
}

function register_form(show) {
    toggle_in_out($('div.registration'), show)
}

function register_form_validation(accepted) {
    if(accepted){
        $('div.registration .text').html("Accepté")
    }
    else {
        $('div.registration .text').html("Refusé")
    }
    // Afficher accepter ou pas et afficher le bouton close
}

function bookmaker_form(show) {
    toggle_in_out($('div.bookmaker'), show)
}

function bookmaker_form_validation(accepted) {
    if(accepted){
        $('div.bookmaker .text').html("Accepté")
    }
    else {
        $('div.bookmaker .text').html("Refusé")
    }
    // Afficher accepter ou pas et afficher le bouton close
}

// Events Handler
$(document).ready(function() {
    $('.btn_accept_registration').click(function() {
        call_client('accept_registeration');
    });
    
    $('.btn_cancel_registration').click(function() {
        call_client('cancel_registeration');
    });

    $('.btn_accept_bookmaker').click(function() {
        call_client('accept_bookmaker', {
            'fighter': $('input[name="bookmaker_fighter"]:checked').val(),
            'amount': parseInt($('input#amount').val())
        });
    });
    
    $('.btn_cancel_bookmaker').click(function() {
        call_client('cancel_bookmaker');
    });
});


//*******************************************/
//***************** TOOLS *******************/
//*******************************************/
function call_client(event, data) {
    data = data || {}
    $.post('http://fightclub/' + event, JSON.stringify(data));
}

function toggle_in_out(obj, show) {
    obj.removeClass('initial');

    if (show && !obj.hasClass('in')) {
        obj.removeClass('out');
        obj.addClass('in');
    }
    else if (!show && !obj.hasClass('out') && obj.hasClass('in')) {
        obj.removeClass('in');
        obj.addClass('out');
    }
}

function msToTime(duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;
  
    resp = "";
    if (hours > 0) {
        resp = hours + ":";
    }
    return resp + minutes + ":" + seconds;
}

(function($) {
    $.fn.textfill = function(options) {
        var parent = this.parent();

        while(this.width() > parent.width()) {
            this.css('font-size', parseFloat(this.css('font-size')) - 0.1);
        }

        return this;
    }
})(jQuery);