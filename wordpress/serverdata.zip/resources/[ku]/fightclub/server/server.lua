ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<  INITIALIZATION >>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
local mock_fighters_used = false

local tournament = {}

tournament.id = 0
tournament.is_started = false

tournament.registration = {}
tournament.registration.registered = {}
tournament.registration.registered_count = 0
tournament.registration.is_started = false
tournament.registration.delay = Configs.registration_delay
tournament.registration.time_remaining = 0
tournament.registration.fee = Configs.registration_fee

tournament.bookmaker = {}
tournament.bookmaker.is_started = false
tournament.bookmaker.delay = Configs.bookmaker_delay
tournament.bookmaker.time_remaining = 0

tournament.info = {}
tournament.info.round_counts = Configs.round_count -- combat rounds
tournament.info.round_delay = Configs.round_delay
tournament.info.organisation_percentage = Configs.organisation_percentage

tournament.info.organization_bet_percentage = Configs.organization_bet_percentage
tournament.info.organization_fee_percentage = Configs.organization_fee_percentage

tournament.fighter_count = 0

tournament.active_fighters = {}
tournament.active_fighters_count = 0

tournament.rounds = {}
tournament.rounds_count = 0

tournament.ongoing = false
tournament.ongoing_round = -1
tournament.ongoing_combat = -1

tournament.pot = {}
tournament.pot.loosers = 0
tournament.pot.winners = 0

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<  SCENARIO >>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function start_scenario()
    tournament.is_started = true
    reset_tournament()
    create_tournament()

    Citizen.CreateThread(function()
        while tournament.is_started do
            TriggerClientEvent('ku:scenario:fightclub:client:update_tournament', -1, tournament)
            Wait(1000)
        end

        -- Send a last time the tournament to have tournament.is_started = false on client
        TriggerClientEvent('ku:scenario:fightclub:client:update_tournament', -1, tournament)
    end)

    Citizen.CreateThread(function()
        --[[ REGISTRATIONS ]]
        tournament.registration.is_started = true
        execute_event_chuncks('registration', tournament.registration.delay)
        tournament.registration.is_started = false

        create_mock_fighters(0)
        add_registered_to_tournament()

        if tournament.rounds_count == 0 then
            print_debug("Not enough fighters")
        else
            print_debug("Tournament round count: " .. tournament.rounds_count)

            for t_round_index = 1, tournament.rounds_count, 1 do
                print_debug("Start tounrament round #: " .. t_round_index)

                init_tournament_round(t_round_index)

                for c_index, combat in pairs(tournament.rounds[t_round_index].combats) do
                    tournament.ongoing_round = t_round_index
                    tournament.ongoing_combat = c_index

                    tournament.ongoing = tournament.rounds[tournament.ongoing_round].combats[tournament.ongoing_combat]

                    print_debug("Start combat #: " .. c_index)
                    print_debug("Red: " .. tournament.ongoing.fighters.red.name .. " #" .. tournament.ongoing.fighters.red.id)
                    print_debug("Blue: " .. tournament.ongoing.fighters.blue.name .. " #" .. tournament.ongoing.fighters.red.id)

                    TriggerClientEvent('ku:scenario:fightclub:client:dress_fighter', tournament.ongoing.fighters.red.id, 'red')
                    TriggerClientEvent('ku:scenario:fightclub:client:dress_fighter', tournament.ongoing.fighters.blue.id, 'blue')

                    --[[ BOOKMAKER ]]
                    tournament.bookmaker.is_started = true
                    execute_event_chuncks('bookmaker', Configs.bookmaker_delay)
                    tournament.bookmaker.is_started = false

                    --[[ COMBAT ]]
                    local is_ko = false
                    tournament.ongoing.round.is_started = true
                    for c_round_index = 1, Configs.round_count, 1 do
                        tournament.ongoing.round.number = c_round_index

                        tournament.ongoing.round.rest = false

                        is_ko = execute_event_chuncks('round', Configs.round_delay)
                        if is_ko then break end

                        if c_round_index < Configs.round_count then
                            tournament.ongoing.round.rest = true
                            execute_event_chuncks('round_rest', Configs.round_rest_delay)
                        end

                        save_tournament_data()
                    end
                    tournament.ongoing.round.is_started = false

                    local winner = nil
                    local looser = nil
                    if tournament.ongoing.fighters.blue.health > tournament.ongoing.fighters.red.health then
                        remove_fighter_from_tournament(tournament.ongoing.fighters.red)

                        winner = tournament.ongoing.fighters.blue
                        looser = tournament.ongoing.fighters.red
                    else
                        remove_fighter_from_tournament(tournament.ongoing.fighters.blue)

                        winner = tournament.ongoing.fighters.red
                        looser = tournament.ongoing.fighters.blue
                    end

                    tournament.ongoing.winner = winner
                    tournament.ongoing.looser = looser

                    distribute_fighter_money(t_round_index)
                    distribute_bet_money()

                    save_tournament_data()

                    TriggerClientEvent('ku:scenario:fightclub:client:undress_fighter', tournament.ongoing.looser.id)

                    tournament.ongoing.round.celebration = true
                    execute_event_chuncks('celebration', Configs.celebration_delay)
                    tournament.ongoing.round.celebration = false

                    TriggerClientEvent('ku:scenario:fightclub:client:undress_fighter', tournament.ongoing.winner.id)
                end
            end
        end
        tournament.is_started = false

        save_tournament_data()
    end)
end

function update_fighter(fighter)
    if tournament.ongoing then
        tournament.ongoing.fighters[fighter.color].health = fighter.health
    end
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<  TOURNAMENT >>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function create_tournament()
    tournament.id = MySQL.Sync.insert('INSERT INTO `fightclub_tournament`(`data`) VALUES(@data)',{
        ['data'] = dump(tournament)
    })

    print_debug('Tounament id: ' .. tournament.id)
end

function reset_tournament()
    tournament.registration.is_started = false
    tournament.registration.time_remaining = 0
    tournament.registration.registered = {}
    tournament.registration.registered_count = 0

    tournament.bookmaker.is_started = false
    tournament.bookmaker.delay = Configs.bookmaker_delay
    tournament.bookmaker.time_remaining = 0

    tournament.fighter_count = 0

    tournament.active_fighters = {}
    tournament.active_fighters_count = 0
    
    tournament.rounds = {}
    tournament.rounds_count = 0
    
    tournament.ongoing = false
    tournament.ongoing_round = -1
    tournament.ongoing_combat = -1
end

function init_tournament_round(round_id)
    local tournament_round = {combats = {}}

    for index = 1, tournament.active_fighters_count, 2 do
        print_debug("Combat: " .. math.ceil(index/2))
        print_debug("Fighter red: " .. tournament.active_fighters[index].name)
        print_debug("Fighter blue: " .. tournament.active_fighters[index+1].name)

        local combat = {
            fighters = {
                red = tournament.active_fighters[index],
                blue = tournament.active_fighters[index+1]
            },
            round = {
                is_started = false,
                rest = false,
                celebration = false,
                number = -1,
                time = 0
            },
            bets = {},
            rewards = {
                winner = 0,
                looser = 0
            }
        }

        table.insert(tournament_round.combats, combat)
    end

    table.insert(tournament.rounds, tournament_round)
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<  REGISTRATION >>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>

function create_mock_fighters(mock_fighters)
    local fighter_count = mock_fighters

    for count = 1, fighter_count, 1 do
        mock_fighters_used = true
        register_fighter(1, count)
    end
end

function register_fighter(id, idx)
    local player = ESX.GetPlayerFromId(id)

    local accepted = false

    if idx then
        player.name = player.name .. " " .. idx
    end

    if player.getAccount("bank").money >= tournament.registration.fee then
        player.removeAccountMoney("bank", tournament.registration.fee)
        fichtclub_account('add', tournament.registration.fee)

        print_debug("Register fighter player #" .. id)

        local name = player.name

        local fighter = {
            id = player.source,
            identifier = player.identifier,
            name = player.name,
            health = 0
        }
    
        table.insert(tournament.registration.registered, fighter)
        tournament.registration.registered_count = tournament.registration.registered_count + 1

        accepted = true
    end

    TriggerClientEvent('ku:scenario:fightclub:client:tournament_fee', id, accepted)
end

function add_registered_to_tournament()
    local tournament_fighter_count = 2^math.floor(math.log(tournament.registration.registered_count, 2))

    print_debug("Tournament fighter registered: " .. tournament.registration.registered_count)
    print_debug("Tournament maximum fighter count: " .. tournament_fighter_count)

    for index = 1, tournament.registration.registered_count, 1 do
        local registered = tournament.registration.registered[index]

        if index <= tournament_fighter_count then
            print_debug("Add fighter for tournament: " .. registered.name)
            registered.reward = 0

            table.insert(tournament.active_fighters, registered)
            tournament.active_fighters_count = tournament.active_fighters_count + 1
            tournament.fighter_count = tournament.fighter_count + 1
        else
            ESX.GetPlayerFromId(registered.identifier).addAccountMoney("bank", tournament.registration.fee)
            fichtclub_account('remove', tournament.registration.fee)

            -- TODO: Send a message to the registered player that he will be part or not of the tournament
            print_debug("Remove fighter for tournament: " .. registered.name)
        end
    end

    tournament.rounds_count = math.floor(math.log(tournament.active_fighters_count, 2))
end

function remove_fighter_from_tournament(fighter)
    for i, f in pairs(tournament.active_fighters) do
        if (mock_fighters_used and f.name == fighter.name) or ((not mock_fighters_used) and f.id == fighter.id) then
            print_debug("Remove fighter from tournament: " .. fighter.name)
            table.remove(tournament.active_fighters, i)
            tournament.active_fighters_count = tournament.active_fighters_count - 1
            break
        end
    end
end

function save_tournament_data()
    print_debug("Save tournament data")
    MySQL.Async.execute('UPDATE `fightclub_tournament` SET data = @data WHERE id = @id',
    {
        ['id'] = tournament.id,
        ['data'] = dump(tournament)
    })
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<  BOOKMAKER >>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function place_bet(source, fighter, amount)
    local player = ESX.GetPlayerFromId(source)

    local accepted = false

    if player.getAccount("bank").money >= amount then
        player.removeAccountMoney("bank", amount)
        fichtclub_account('add', amount)

        local bet = {
            round = tournament.ongoing_round,
            combat = tournament.ongoing_combat,
            gambler_identifier = player.identifier,
            fighter_identifier = ESX.GetPlayerFromId(tournament.ongoing.fighters[fighter].id).identifier,
            amount = amount
        }

        table.insert(tournament.ongoing.bets, bet)

        accepted = true
    end

    TriggerClientEvent('ku:scenario:fightclub:client:bookmaker_bet', source, accepted)
end

function distribute_bet_money()
    local pot_total = 0
    local pot = 0
    local winner = tournament.ongoing.winner.identifier

    for idx, bet in pairs(tournament.ongoing.bets) do
        if bet.fighter_identifier ~= winner then
            pot_total = pot_total + bet.amount
        end

        pot = pot_total * ((100-tournament.info.organization_bet_percentage)/100)
    end

    for idx, bet in pairs(tournament.ongoing.bets) do
        if bet.fighter_identifier == winner then
            reward = bet.amount
            if pot_total > 0 then
                reward = reward + (pot * (reward/pot_total))
            end

            ESX.GetPlayerFromIdentifier(bet.gambler_identifier).addAccountMoney("bank", reward)
            fichtclub_account('remove', reward)

            bet.reward = reward
        end
    end
end

-- TODO: REFACTOR
function distribute_fighter_money(round)
    local winner_reward = 0
    local looser_reward = 0

    tournament.pot.winners = ((tournament.fighter_count * tournament.registration.fee) * (1-(tournament.info.organization_fee_percentage/100))) - tournament.pot.loosers

    if tournament.rounds_count == 1 then
        if round == 1 then
            winner_reward = tournament.pot.winners * 1
        end
    elseif tournament.rounds_count == 2 then
        if round == 1 then
            winner_reward = tournament.registration.fee * 0.25
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 2 then
            winner_reward = tournament.pot.winners * 0.7
            looser_reward = tournament.pot.winners * 0.3
        end
    elseif tournament.rounds_count == 3 then
        if round == 1 then
            winner_reward = tournament.registration.fee * 0.25
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 2 then
            winner_reward = tournament.registration.fee * 0.5
            looser_reward = tournament.registration.fee * 0.25
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 3 then
            winner_reward = tournament.pot.winners * 0.7
            looser_reward = tournament.pot.winners * 0.3
        end
    elseif tournament.rounds_count == 4 then
        if round == 1 then
            winner_reward = tournament.registration.fee * 0.25
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 2 then
            winner_reward = tournament.registration.fee * 0.25
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 3 then
            winner_reward = tournament.registration.fee
            looser_reward = tournament.registration.fee * 0.5
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 4 then
            winner_reward = tournament.pot.winners * 0.7
            looser_reward = tournament.pot.winners * 0.3
        end
    elseif tournament.rounds_count == 5 then
        if round == 1 then
            winner_reward = tournament.registration.fee * 0.25
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 2 then
            winner_reward = tournament.registration.fee * 0.25
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 3 then
            winner_reward = tournament.registration.fee
            looser_reward = tournament.registration.fee * 0.5
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 4 then
            winner_reward = tournament.registration.fee * 2
            looser_reward = tournament.registration.fee * 1
            tournament.pot.loosers = tournament.pot.loosers + winner_reward + looser_reward
        elseif round == 5 then
            winner_reward = tournament.pot.winners * 0.7
            looser_reward = tournament.pot.winners * 0.3
        end
    end

    ESX.GetPlayerFromIdentifier(tournament.ongoing.winner.identifier).addAccountMoney("bank", winner_reward)
    ESX.GetPlayerFromIdentifier(tournament.ongoing.looser.identifier).addAccountMoney("bank", looser_reward)

    fichtclub_account('remove', winner_reward)
    fichtclub_account('remove', looser_reward)

    tournament.ongoing.winner.reward = tournament.ongoing.winner.reward + winner_reward
    tournament.ongoing.looser.reward = tournament.ongoing.looser.reward + looser_reward

    tournament.ongoing.rewards.winner = winner_reward
    tournament.ongoing.rewards.looser = looser_reward
end

-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<  TOOLS >>>>>>>>>>>>>>>>>>>>>>>
-- <<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>
function fichtclub_account(action, amount)
    if Configs.company_bank_account then
        -- Get company account
    else
        account = ESX.GetPlayerFromIdentifier(
            MySQL.Sync.fetchAll('SELECT identifier FROM users WHERE job = "fightclub" AND job_grade = 4 LIMIT 1', {})[1].identifier
        )
    end

    if action == 'add' then
        account.addAccountMoney("bank", amount)
    elseif action == 'remove' then
        account.removeAccountMoney("bank", amount)
    end
end

function execute_event_chuncks(event, delay)
    local clock = GetGameTimer() + delay

    print_debug("Start event chunck: " .. event)
    while GetGameTimer() < clock do
        t = clock - GetGameTimer()
        if event == "registration" then
            tournament.registration.time_remaining = t
        elseif event == "bookmaker" then
            tournament.bookmaker.time_remaining = t
        elseif event == "round" or event == "round_rest" then
            tournament.ongoing.round.time = t

            if tournament.ongoing.fighters.red.health < 1 or tournament.ongoing.fighters.blue.health < 1 then
                return true
            end
        end
        Wait(1000)
    end
    print_debug("End event chunck: " .. event)
    return false
end