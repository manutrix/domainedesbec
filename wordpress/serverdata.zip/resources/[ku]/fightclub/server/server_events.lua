RegisterServerEvent('ku:scenario:fightclub:server:start_scenario')
AddEventHandler('ku:scenario:fightclub:server:start_scenario', function()
    start_scenario()
end)

RegisterServerEvent('ku:scenario:fightclub:server:register_fighter')
AddEventHandler('ku:scenario:fightclub:server:register_fighter', function()
    register_fighter(source)
end)

RegisterServerEvent('ku:scenario:fightclub:server:place_bet')
AddEventHandler('ku:scenario:fightclub:server:place_bet', function(fighter, amount)
    place_bet(source, fighter, amount)
end)

RegisterServerEvent('ku:scenario:fightclub:server:fighter_report')
AddEventHandler('ku:scenario:fightclub:server:fighter_report', function(fighter)
    update_fighter(fighter)
end)