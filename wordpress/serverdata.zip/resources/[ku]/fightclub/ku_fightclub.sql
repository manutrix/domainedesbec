USE `[PUT YOUR DATABASE NAME HERE]`;

CREATE TABLE `fightclub_tournament` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`data` BLOB NULL,

	PRIMARY KEY (`id`)
);

INSERT INTO jobs(`name`, `label`) VALUES ('fightclub','Fight Club')

INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES ('fightclub', '4', 'boss', 'Boss', '0', '{}', '{}')
INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES ('fightclub', '3', 'chief_security', 'Chief Security', '0', '{}', '{}')
INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES ('fightclub', '2', 'security', 'Security', '0', '{}', '{}')