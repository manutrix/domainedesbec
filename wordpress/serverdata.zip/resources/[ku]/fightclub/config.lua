minute = 60 * 1000

Configs = {}

Configs.enable_debug_messages = true

Configs.area_size = 25
Configs.fighter_health = 1000
Configs.fighter_health_restore = 10
--Configs.registration_delay = 15 * minute -- 15 minutes
Configs.registration_delay = 0.1 * minute -- 15 minutes
--Configs.bookmaker_delay = 5 * minute -- 5 minutes
Configs.bookmaker_delay = .2 * minute -- 5 minutes
Configs.round_count = 3
Configs.round_delay = .2 * minute -- 1 minutes
Configs.round_rest_delay = .2 * minute -- 15 secondes
--Configs.organisation_percentage = 10
Configs.organization_bet_percentage = 20
Configs.organization_fee_percentage = 15
Configs.registration_fee = 5000

Configs.celebration_delay = .3 * minute -- 1 minutes

Configs.tournament_fighter_count = 8

Configs.company_bank_account = false

Configs.fighter = {}
Configs.fighter.clothes = {}
Configs.fighter.clothes.male = {}
Configs.fighter.clothes.male.red = {
    tshirt_1 = -1,
    tshirt_2 = -1,
    torso_1 = -1,
    torso_2 = 1,
    shoes_1 = 55,
    shoes_2 = 5,
    pants_1 = 27,
    pants_2 = 4,
    arms = 15,
    helmet_1 = -1,
    helmet_2 = -1,
	bags_1 = 0,
	bags_2 = 0,
	ears_1 = -1,
	ears_2 = -1,
	glasses_1 = 0,
    glasses_2 = 0,
    mask_1 = -1,
    mask_2 = -1,
    watches_1 = -1,
    watches_2 = -1,
    bracelets_1 = -1,
    bracelets_2 = -1,
    chain_1 = -1,
    chain_2 = -1
}
Configs.fighter.clothes.male.blue = {
    tshirt_1 = -1,
    tshirt_2 = -1,
    torso_1 = -1,
    torso_2 = 1,
    shoes_1 = 55,
    shoes_2 = 3,
    pants_1 = 27,
    pants_2 = 1,
    arms = 15,
    helmet_1 = -1,
    helmet_2 = -1,
	bags_1 = 0,
	bags_2 = 0,
	ears_1 = -1,
	ears_2 = -1,
	glasses_1 = 0,
    glasses_2 = 0,
    mask_1 = -1,
    mask_2 = -1,
    watches_1 = -1,
    watches_2 = -1,
    bracelets_1 = -1,
    bracelets_2 = -1,
    chain_1 = -1,
    chain_2 = -1
}

--[[
-- game settings
Configs.delay_before_unlock = 30  * 60 * 1000
Configs.delay_between_messages = 5 * 1000
Configs.delay_between_clues = 10 * 60 * 1000
Configs.delay_between_gps = 30 * 1000

-- initial scenario props
Configs.cash_case_coords = { x = 1974.941, y = 686.2162, z = 162.3786 }

-- scenario messages
Configs.scenario_initial_messages = {}
Configs.scenario_initial_messages[0] = "ATTENTION!!! Avis à la population ATTENTION!!!"
Configs.scenario_initial_messages[1] = "L'avion d'un mafieux s'est écrasé quelque part"
Configs.scenario_initial_messages[2] = "Il transportait avec lui une valise contenant 100 000$"
Configs.scenario_initial_messages[3] = "Il s'agit d'un petit jet d'affaire"
Configs.scenario_initial_messages[4] = "Vous pouvez tous participer à la recherche de l'avion"
Configs.scenario_initial_messages[5] = "Si nous avons plus d'information nous vous les communiquerons"

Configs.scenario_clue_messages_title = "Nouvelles informations:"
Configs.scenario_clue_messages = {}
Configs.scenario_clue_messages[0] = "l'avion n'était plus au dessus du centre-ville au moment de l'écrasement"
Configs.scenario_clue_messages[1] = "L'avion aurait touché de l'eau au moment de l'écrasement"
Configs.scenario_clue_messages[2] = "La dernière position de l'avion était vers l'EST"
Configs.scenario_clue_messages[3] = "L'avion n'aurait pas touché de l'eau salée. Il s'agirait plus d'un lac"
Configs.scenario_clue_messages[4] = "Des gens faisant du base jump auraient vu l'avion passer à basse altitude au dessus de leur tête"

Configs.scenario_cash_case_owner_messages = {}
Configs.scenario_cash_case_owner_messages[0] = "La valise a été menottée à votre poignet"
Configs.scenario_cash_case_owner_messages[1] = "À chaque 30 secondes votre position sera dévoilée à tout le monde"
Configs.scenario_cash_case_owner_messages[2] = "COURREZ!!! SAUVEZ-VOUS!!! PROTÉGEZ VOTRE BUTIN!!!"

Configs.scenario_manhunt_messages = {}
Configs.scenario_manhunt_messages[0] = "ATTENTION! Le butin a été trouvé!"
Configs.scenario_manhunt_messages[1] = "La position du fugitif sera affiché sur votre carte de la ville"
Configs.scenario_manhunt_messages[2] = "Vous allez recevoir un message quand elle sera mise à jour"
Configs.scenario_manhunt_messages[3] = "BONNE CHASSE!!!"
--]]