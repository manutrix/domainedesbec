---
id: 24
name: 'queueLimit'
---
The maximum number of connection requests the pool will queue before returning an error from `getConnection`.
If set to `0`, there is no limit to the number of queued connection requests. (Default: `0`)