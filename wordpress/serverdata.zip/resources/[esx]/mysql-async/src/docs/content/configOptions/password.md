---
id: 6
name: 'password | pwd'
---
The password of that MySQL user.