---
id: 11
---
## Setup

To Install mysql-async your first need to have installed a MySQL Database.