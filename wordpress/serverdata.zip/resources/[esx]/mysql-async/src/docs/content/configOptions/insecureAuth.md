---
id: 12
name: 'insecureAuth'
---
Allow connecting to MySQL instances that ask for the old (insecure) authentication method. (Default: `false`)